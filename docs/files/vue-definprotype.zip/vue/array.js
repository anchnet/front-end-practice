import observeArr from './observeArr'
// 首先保存一下所有要更改的方法有哪些
import { ARRAY_METHODS } from './config'
// 如果对原型修改，必须要先有原型
let originArrayMethods = Array.prototype // 是一个原型的引用
//创建一个新对象
let arrMethods = Object.create(originArrayMethods)
ARRAY_METHODS.map(function (m) {
  arrMethods[m] = function () {
    //拿到所有的args,并转化为真实数组 Arrray.from()
    //slice会返回一个数组
    let args = Array.prototype.slice.call(arguments)
    //执行原本的数组的方法，同时这里谁调用this指向就是谁，
    //功能交给原来的方法做
    let rt = originArrayMethods[m].apply(this, args)
    // 这里的push unshift splice 新增的一项不确定，所以要let newArry
    console.log('数组新方法', args);
    let newArray;//因为这里取出来的arg 都是array
    switch (m) {
      case 'push':
      case 'unshift':
        newArray = args
        break;
      //第一个是位置从哪开始。删除几项，新增一个不确定项
      // arrMethods.splic(0,1,{})
      case 'splice':
        newArray = args.slice(2)
        break;
      default:
        break;
    }
    //拿到了新增的数组，就可以去观察
    newArray && observeArr(newArray)
    return rt
  }
})
export {
  arrMethods
}
