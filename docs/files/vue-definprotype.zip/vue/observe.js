import Observer from './observer'
//将data进行观察
function observe(data) {
  //我们要观察都是对象
  if (typeof data !== 'object' || data === null) {
    // 不进行观察
    return
  }
  // 是对象的话 ，把data交给Observer类或者构造函数来管理
  return new Observer(data)
}
export default observe