import proxyData from './proxy'
import observe from './observe'
function initState(vm) {
  console.log(vm);
  // 取出 $options,就不用每次都用vm.$options
  let options = vm.$options
  // 判断options.data存在，调用initData(),computed，watch都是有数据的，有不同的init，要分开处理
  if (options.data) {
    initData(vm)
  }

}
function initData(vm) {
  //现在已经拿到options，现在要拿到data，同理拿到
  let data = vm.$options.data
  //我们希望挂载一个临时的data来保留用户的原始data
  // 并且在没经过设置的时候 我们在src/index.js访问数据 需要vm.data.title
  // 这个时候都不能访问到，因为data是一个函数
  //而我们的操作习惯是vm.title或者this.title,跳过了data这一节
  //从而引出_data,即在vm上挂载的临时的data

  // 判断data是函数的话，需要执行，
  // 并且这个函数返回的对象this需要指向vm实例
  data = vm._data = typeof data === 'function' ? data.call(vm) : data || {}
  for (const key in data) {
    // console.log(key);
    // definProperty(data, key, {
    //   get() { },
    //   set(newVal){}
    // })
    proxyData(vm, '_data', key)
  }
  observe(vm._data)
}
export {
  initState
}