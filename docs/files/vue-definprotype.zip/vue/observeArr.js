import observe from './observe'
function observeArr(arr) {

  for (let i = 0; i < arr.length; i++) {
    //又回到了observe 进行观察

    //每一项里有可能还是object，进入到Observer，所以在observer里再次递归一遍
    observe(arr[i])
  }
}
export default observeArr