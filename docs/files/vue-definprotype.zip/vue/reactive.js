//专门处理响应式数据
import observe from './observe';
function definReactiveData(data, key, value) {
  observe(value)
  Object.defineProperty(data, key, {
    get() {
      console.log('获取响应式数据', value);
      return value
    },
    set(newValue) {
      console.log('设置响应式数据', newValue);
      if (newValue === value) return
      observe(newValue)
      value = newValue
    }
  })
}
export default definReactiveData