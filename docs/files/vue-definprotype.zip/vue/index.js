import { initState } from './init'
function Vue(options) {
  this._init(options)
}
Vue.prototype._init = function (options) {
  var vm = this; //阅读时候语意化
  vm.$options = options//options挂载到实例上

  // 初始化状态
  // 这里可以处理多个状态，initEvents，initLifecycle
  // 接收一个实例，可以拿到实例下到options，而且initState也需要操作实例，所以要传入vm
  initState(vm);
}
export default Vue