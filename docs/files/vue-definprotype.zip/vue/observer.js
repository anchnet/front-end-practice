import definReactiveData from './reactive'
import { arrMethods } from './array'
import observeArr from './observeArr'
function Observer(data) {
  //判断是否为数组
  if (Array.isArray(data)) {
    //要更改数据里操作array的方法，如果传入的是array，就把整个arrMethods在原型链上
    data.__proto__ = arrMethods
    // console.log(data); //看到__proto__是自己写的方法
    //问题：二维数组的处理 observeArr
    observeArr(data)

  } else {
    // 此时执行walk方法
    this.walk(data)
  }
}
Observer.prototype.walk = function (data) {
  //拿到所有的key value重新定义
  let keys = Object.keys(data)
  // console.log(keys);
  for (let i = 0; i < keys.length; i++) {
    // 拿到key value 我们就可以直接用definproperty
    let key = keys[i],
      value = data[key]
    // 写一个reactive的模块
    definReactiveData(data, key, value)

  }
}
export default Observer
// 这里我们对对象和对数组对处理对方法不一样
// { } definproperty
// []自己实现方法了