import Vue from "vue";

let vm = new Vue({
  el: '#app',
  data() {
    return {
      title: '技术分享会',

      result: {
        code: 0,
        data: {
          name: 'tom',
          age: 18
        }
      },
      personnel: [
        {
          id: 1,
          name: '组一'
        }, {
          id: 2,
          name: '组二'
        }, {
          id: 3,
          name: '组三'
        }
      ]

    }
  }
})
vm.personnel[0].id = 2
console.log(vm.personnel);
// vm.personnel.push({ id: 4, name: '组四' })
// console.log(vm.personnel);
vm.result.code = 20;
console.log(vm.result.code = 20);
// vm.personnel.splice(0, 1, { id: 4, name: '组五' })
// console.log(vm.personnel);
// vm.data.title
// vm.title
// this.title